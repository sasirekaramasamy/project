package com.calling;

import com.niit.DAOimpl.UserDAOImpl;

public class InvokeMethod {
public static void main(String[] args) {
	UserDAOImpl i=new UserDAOImpl();
	i.show("xxyz@gmail.com");
	
}
}
