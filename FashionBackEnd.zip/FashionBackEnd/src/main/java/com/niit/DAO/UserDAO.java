package com.niit.DAO;

public interface UserDAO {
	 public void show(String email);

}
