package com.niit.DAOimpl;

import com.niit.DAO.UserDAO;


public class UserDAOImpl implements UserDAO {

	public void show(String email) {
		System.out.println(email);
		
	}
	

}
