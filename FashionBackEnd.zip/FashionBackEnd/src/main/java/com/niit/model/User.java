package com.niit.model;

import java.io.Serializable;

public class User implements Serializable{
	 
	private static final long serialVersionUID = 1L;
	private String email;
	private String name;
	private String phone;
	private String address;
	private String country;
	public User()
	{
		
	}
	
	@Override
	public String toString() {
		return "User [email=" + email + ", name=" + name + ", phone=" + phone + ", address=" + address + ", country="
				+ country + "]";
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
}
